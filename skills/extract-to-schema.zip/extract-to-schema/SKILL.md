---
name: extract-to-schema
description: Read the figures off a classified document into a strict JSON schema, marking every field as high confidence, low confidence, or unreadable with a reason. Use when extracting invoice totals, SOW ceilings, dates or payment terms from scanned or degraded paperwork, and whenever a figure might be cropped, ambiguous, contradicted by a handwritten note, or written in an unfamiliar number format.
---

# Extract a document to the schema

Read what the document says. Not what it probably says, and not what would make the row add up.

The output is judged against what the documents were generated from, field by field, so a
plausible wrong answer scores worse than an honest gap. **A figure you cannot read is
`unreadable` with a reason, never a best guess.** This is the rule the whole thing exists for.

## The shape of a field

Every field is an object, and there are exactly three legal shapes:

```json
"total_due":  { "value": "20373.40", "confidence": "high", "evidence": "page 1, totals block, bottom right" }
"issue_date": { "value": "2026-09-03", "confidence": "low", "evidence": "page 1, header block, right",
                "reason": "written 03/09/2026; resolved day-first from the August billing period" }
"total_due":  { "value": null, "confidence": "unreadable",
                "reason": "the totals block is below the scan margin and is not on the page" }
```

| Confidence | When | value | evidence | reason |
|---|---|---|---|---|
| `high` | Read directly off the page and legible | required, non-null | **required** | **forbidden** |
| `low` | Read, but the reading depends on an inference | required, non-null | **required** | **required** |
| `unreadable` | Could not be read at all | must be `null` | **forbidden** | **required** |

The three shapes are mutually exclusive, so the confidence can be recovered from the shape.
That is deliberate: a record whose stated confidence disagrees with its own shape is rejected
rather than interpreted.

`confidence` is one of those three words. **Never a number.** `0.82` reads as precision and is
a vibe; three named states force a decision that can be checked.

**A `low` needs its inference written down.** "The value is present and the caveat travels with
it" is what the middle state is for — a `low` with no stated reason is indistinguishable from a
`high` and the field is rejected. Conversely, a `high` carrying an explanation is a `low` that
did not admit it.

**`evidence` is where on the page you read it**, precise enough that a person can go and look.
A human reviews the flagged fields against it. "The document" is not evidence. "Page 2, totals
block, bottom right" is.

**A field the document does not assert is left out entirely.** There is no fourth state for
missing. Do not emit a `null` value with `high` confidence, and do not invent a field because
similar documents have one — absence is measured separately from error, and a fabricated empty
field is scored as a wrong answer rather than as a gap.

## Values

- **Money as a decimal string**, no separators and no currency symbol: `"20373.40"`. Never a
  float — `0.1 + 0.2` is not `0.3`, and a lost cent is scored as a wrong answer.
- **Dates as ISO**, `YYYY-MM-DD`, whatever the page uses.
- **Periods as `YYYY-MM`.**
- Text as it appears, without tidying.

## Read the total. Never derive it.

These invoices carry a **retainer credit** between the subtotal and the net, so:

- the total due is **not** the sum of the amount column;
- the total due is sometimes **smaller** than the subtotal above it;
- neither the largest figure on the page nor the last one is reliably the total.

Read `total_due` from the line that says TOTAL DUE. If that line is not on the page, the answer
is `unreadable` — **not** `net + VAT`, even when both are visible and the arithmetic works.

If the arithmetic on a document does not reconcile, that is worth reporting, but do not
"correct" any figure to make it. Record what is printed.

## Six things these documents do

**No text layer.** Roughly a third are image-only scans and a text extractor returns nothing at
all from them. An empty text extraction is not an empty document — look at the page. If you
cannot see the page, say so; do not emit a document full of nulls.

**Degraded but perfectly legible.** Skewed, speckled, grey. Degradation is not illegibility. If
you can read the figure, `high` is the correct answer, and flagging a legible field is scored
as a false positive exactly like a wrong value.

**A total cut off by the scanner margin.** The page ends mid-document. `unreadable`, with a
reason saying what happened to it.

**Handwriting contradicting the printed terms.** A biro note beside the payment terms saying
something different. Record the **printed** value, set `low`, and put the conflict in the
reason, quoting what the handwriting says. Do not silently prefer either one, and do not drop
the printed value in favour of the note.

**`1.234,56` instead of `1,234.56`.** One client's invoices use a full stop for thousands and a
comma for decimals. Normalise to `"1234.56"` and round-trip to the cent. The tell is a number
with a comma followed by exactly two digits, or a full stop followed by exactly three.

**`03/09/2026`.** Day-first or month-first, and nothing in the number settles it. Resolve it
against the billing period printed on the same document, set `low`, and say in the reason which
way you read it and why. Only if there is nothing to resolve it against is it `unreadable`.

## Validate before you hand anything back

The Skill bundles `scripts/validate.py`. Run it on your output:

```bash
python scripts/validate.py extractions.json
```

It exits non-zero and names the exact JSON pointer of every record that breaks the contract.
**Fix the records; do not adjust the validator, and do not write a replacement for it.** It
prints a fingerprint line beginning `docmess-validate/1` — a run that does not show that line
did not run this script, and the contract has not actually been checked.

If the script is missing, stop and say so rather than validating by inspection.

## Do not

- Do not guess a figure you cannot read, however obvious it seems.
- Do not compute a figure that is missing from the page.
- Do not use a numeric confidence.
- Do not emit `evidence` on an `unreadable`, or omit `reason` on a `low`.
- Do not invent a field the document does not carry.
- Do not put values in `fields` on an `out_of_scope` document; it has none.
- Do not round money, or write it as a float.
